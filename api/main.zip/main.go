package main

import (
	"fmt"
	"net/http"
)

type Human struct {
	Sex string
	Age int
	IPK float64
}

type Doc struct {
	Document string `json:"document"`
}

type Pens interface {
	Check(h *Human, d *Doc) string
}

type FZ400 struct{}

func (f *FZ400) Check(h *Human, d *Doc) string {
	switch h.Sex {
	case "male":
		if h.Age > 55 && h.IPK > 30 {
			return fmt.Sprintf("Проверить право на СПН: Гражданину уже %d лет. Величина ИПК: %f \n Требуются документы %s", h.Age, h.IPK, d.Document)
		} else {
			return fmt.Sprintf("FZ400: %s, %d", h.Sex, h.Age)
		}
	case "female":
		if h.Age > 55 {
			return fmt.Sprintf("FZ400: %s, %d", h.Sex, h.Age)
		} else {
			return fmt.Sprintf("FZ400: %s, %d", h.Sex, h.Age)
		}
	}
	return fmt.Sprintf("FZ400: %s, %d", h.Sex, h.Age)
}

type FZ166 struct{}

func (f *FZ166) Check(h *Human, d *Doc) string {
	switch h.Sex {
	case "male":
		if h.Age > 55 {
			return fmt.Sprintf("Гражданину уже %d лет. Через %d лет можно получить социальную пенсию", h.Age, 70-h.Age)
		} else {
			return fmt.Sprintf("FZ166: %s, %d", h.Sex, h.Age)
		}
	case "female":
		if h.Age > 55 {
			return fmt.Sprintf("FZ166: %s, %d", h.Sex, h.Age)
		} else {
			return fmt.Sprintf("FZ166: %s, %d", h.Sex, h.Age)
		}
	}
	return fmt.Sprintf("FZ166: %s, %d", h.Sex, h.Age)
}

func apiHandler(w http.ResponseWriter, r *http.Request) {
	f400 := &FZ400{}
	f166 := &FZ166{}
	h := &Human{Sex: "male", Age: 56, IPK: 31}
	d := &Doc{Document: "document"}
	fmt.Println(f400.Check(h, d))
	fmt.Println(f166.Check(h, d))
	fmt.Fprintln(w, f400.Check(h, d))
	fmt.Fprintln(w, f166.Check(h, d))
}

func main() {
	f400 := &FZ400{}
	f166 := &FZ166{}
	h := &Human{Sex: "male", Age: 56, IPK: 31}
	d := &Doc{Document: "document"}
	fmt.Println(f400.Check(h, d))
	fmt.Println(f166.Check(h, d))
	http.HandleFunc("/api", apiHandler)
	http.ListenAndServe(":8080", nil)
}
